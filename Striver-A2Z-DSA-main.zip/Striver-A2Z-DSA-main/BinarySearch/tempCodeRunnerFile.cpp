if (ans == m)
            {
                return i;
            }
            else if (ans > m)
            {
                break;
            }