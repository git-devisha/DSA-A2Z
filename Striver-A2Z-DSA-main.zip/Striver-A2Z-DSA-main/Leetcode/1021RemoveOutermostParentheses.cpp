﻿#include <bits/stdc++.h>
using namespace std;

string removeOuterParentheses(string s) {
        
    }

int main()
{

    return 0;
}