ct max element from right
        cout << "The ma